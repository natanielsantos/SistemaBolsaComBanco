#iTech Empires - PHP MySQL CRUD (Create, Read, Update, Delete) Operations using jQuery
##www.itechempires.com

## How to Run/Install ??

1. Create Database and users table.
2. Change configurtion setting in ajax/db_connection.php file according to your host.

Your done.

#follow us on Twitter - @itechempires
#like us on Facebook - https://www.facebook.com/itechempires